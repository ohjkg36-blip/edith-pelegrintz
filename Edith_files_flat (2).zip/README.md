# DFG Editor Launcher (Godot 4.2)
Лаунчер запускає локальний сервер (127.0.0.1:8765) і відкриває вбудований DFG Builder у браузері.
APK збирається через GitHub Actions: Actions -> Build Godot APK -> Run workflow.
