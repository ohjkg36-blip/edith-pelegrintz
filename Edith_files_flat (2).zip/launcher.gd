extends Control

const APP_PATH := "res://DFG_Builder.html"
const PORT := 8765
const URL := "http://127.0.0.1:8765/"
const BG := Color("#0b1c2b")
const PANEL := Color("#101f2d")
const PANEL2 := Color("#142636")
const BORDER := Color("#2b4358")
const TEXT := Color("#e9edf2")
const MUTED := Color("#a9b8c7")
const GREEN := Color("#17613d")

var recent_box: VBoxContainer
var status_label: Label
var settings_popup: AcceptDialog
var lang := "en"
var server := TCPServer.new()
var clients: Array[StreamPeerTCP] = []
var html_bytes := PackedByteArray()

func _ready() -> void:
    _build_ui()
    _refresh_recent()
    _start_server()

func _start_server() -> void:
    html_bytes = FileAccess.get_file_as_bytes(APP_PATH)
    if html_bytes.is_empty():
        status_label.text = "Application file is missing: " + APP_PATH
        return
    var err := server.listen(PORT, "127.0.0.1")
    if err != OK:
        status_label.text = "Local server error: " + str(err)

func _exit_tree() -> void:
    server.stop()

func _process(_delta: float) -> void:
    if not server.is_listening():
        return
    while server.is_connection_available():
        var c := server.take_connection()
        if c:
            clients.append(c)
    for c in clients.duplicate():
        c.poll()
        if c.get_status() != StreamPeerTCP.STATUS_CONNECTED:
            clients.erase(c)
            continue
        var n := c.get_available_bytes()
        if n > 0:
            var req := c.get_utf8_string(n)
            _respond(c, req)
            c.disconnect_from_host()
            clients.erase(c)

func _respond(c: StreamPeerTCP, req: String) -> void:
    var parts := req.get_slice("\r\n", 0).split(" ")
    var path := "/"
    if parts.size() >= 2:
        path = parts[1].split("?")[0].uri_decode()
    var code := "200 OK"
    var ctype := "text/html; charset=utf-8"
    var body := PackedByteArray()
    if path == "/" or path == "/index.html":
        body = html_bytes
    elif path.begins_with("/projects/") and not (".." in path):
        var f := "user://projects/" + path.trim_prefix("/projects/")
        if FileAccess.file_exists(f):
            body = FileAccess.get_file_as_bytes(f)
            if not f.ends_with(".html"):
                ctype = "text/plain; charset=utf-8"
        else:
            code = "404 Not Found"
    else:
        code = "404 Not Found"
    var header := "HTTP/1.1 %s\r\nContent-Type: %s\r\nContent-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n" % [code, ctype, body.size()]
    c.put_data(header.to_utf8_buffer())
    if body.size() > 0:
        c.put_data(body)

func _style_panel(panel: PanelContainer, color: Color = PANEL) -> void:
    var sb := StyleBoxFlat.new()
    sb.bg_color = color
    sb.border_color = BORDER
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(22)
    sb.content_margin_left = 24
    sb.content_margin_right = 24
    sb.content_margin_top = 20
    sb.content_margin_bottom = 20
    panel.add_theme_stylebox_override("panel", sb)

func _label(value: String, size: int, color: Color = TEXT, bold := false) -> Label:
    var l := Label.new()
    l.text = value
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    if bold:
        l.add_theme_color_override("font_shadow_color", Color(0,0,0,0.25))
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return l

func _button(value: String, color: Color = PANEL2, min_h := 54) -> Button:
    var b := Button.new()
    b.text = value
    b.custom_minimum_size = Vector2(0, min_h)
    b.add_theme_font_size_override("font_size", 20)
    b.add_theme_color_override("font_color", TEXT)
    var normal := StyleBoxFlat.new()
    normal.bg_color = color
    normal.border_color = BORDER
    normal.set_border_width_all(2)
    normal.set_corner_radius_all(13)
    normal.content_margin_left = 18
    normal.content_margin_right = 18
    var hover := normal.duplicate()
    hover.bg_color = Color("#1c3b52")
    var pressed := normal.duplicate()
    pressed.bg_color = Color("#126b9c")
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", pressed)
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    return b

func _build_ui() -> void:
    var bg := ColorRect.new()
    bg.color = BG
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var scroll := ScrollContainer.new()
    scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    add_child(scroll)

    var center := CenterContainer.new()
    center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(center)

    var root := VBoxContainer.new()
    root.custom_minimum_size = Vector2(820, 0)
    root.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    root.add_theme_constant_override("separation", 24)
    center.add_child(root)

    var top := HBoxContainer.new()
    top.add_child(_label("DFG Editor Launcher", 36, TEXT))
    top.add_spacer(false)
    var minimize := _button("—", PANEL, 44)
    minimize.custom_minimum_size.x = 52
    minimize.pressed.connect(func(): DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_MINIMIZED))
    top.add_child(minimize)
    var close := _button("×", PANEL, 44)
    close.custom_minimum_size.x = 52
    close.pressed.connect(func(): get_tree().quit())
    top.add_child(close)
    root.add_child(top)

    var hero := PanelContainer.new()
    _style_panel(hero, PANEL)
    root.add_child(hero)
    var hv := VBoxContainer.new()
    hv.add_theme_constant_override("separation", 10)
    hero.add_child(hv)

    var logo := CenterContainer.new()
    logo.custom_minimum_size.y = 170
    var logo_text := _label("🚀", 112, Color("#e7c15c"))
    logo.add_child(logo_text)
    hv.add_child(logo)

    var brand := _label("DFG EDITOR", 58, TEXT, true)
    brand.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hv.add_child(brand)

    var sep := HSeparator.new()
    sep.add_theme_color_override("separator", BORDER)
    hv.add_child(sep)

    var info := HBoxContainer.new()
    info.alignment = BoxContainer.ALIGNMENT_CENTER
    info.add_theme_constant_override("separation", 28)
    var details := VBoxContainer.new()
    details.add_child(_label("Current Version: 45 PRO", 24))
    details.add_child(_label("Install Date: Nov 2026", 22, MUTED))
    info.add_child(details)
    info.add_child(_label("✓", 38, Color("#83c69d"), true))
    var gear := _button("⚙", PANEL2, 58)
    gear.custom_minimum_size.x = 72
    gear.pressed.connect(_show_settings)
    info.add_child(gear)
    hv.add_child(info)

    var recent_panel := PanelContainer.new()
    _style_panel(recent_panel, PANEL)
    root.add_child(recent_panel)
    var rv := VBoxContainer.new()
    rv.add_theme_constant_override("separation", 12)
    recent_panel.add_child(rv)
    rv.add_child(_label("RECENT PROJECTS", 24))
    recent_box = VBoxContainer.new()
    recent_box.add_theme_constant_override("separation", 8)
    rv.add_child(recent_box)

    var launch := _button("LAUNCH APPLICATION     ▶", GREEN, 118)
    launch.add_theme_font_size_override("font_size", 36)
    launch.pressed.connect(_launch_app)
    root.add_child(launch)

    status_label = _label("Ready to launch DFG Builder.", 18, MUTED)
    status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root.add_child(status_label)

    settings_popup = AcceptDialog.new()
    settings_popup.title = "Launcher Settings"
    settings_popup.dialog_text = "Language: English\\nApplication: DFG Builder HTML\\nThe launcher starts a local server and opens the bundled app in your browser."
    settings_popup.ok_button_text = "Close"
    add_child(settings_popup)

func _show_settings() -> void:
    settings_popup.popup_centered(Vector2i(520, 250))

func _refresh_recent() -> void:
    if recent_box == null:
        return
    for child in recent_box.get_children():
        child.queue_free()
    var dir := DirAccess.open("user://")
    if dir:
        dir.make_dir_recursive("projects")
    var files: Array[String] = []
    var d := DirAccess.open("user://projects")
    if d:
        d.list_dir_begin()
        var f := d.get_next()
        while f != "":
            if not d.current_is_dir() and (f.ends_with(".dfg") or f.ends_with(".js") or f.ends_with(".html")):
                files.append(f)
            f = d.get_next()
        d.list_dir_end()
    if files.is_empty():
        recent_box.add_child(_label("No recent projects yet. Your project files will appear here.", 18, MUTED))
        return
    for file_name in files:
        var b := _button("📄   " + file_name, PANEL2, 48)
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.pressed.connect(func(): _open_project("user://projects/" + file_name))
        recent_box.add_child(b)

func _launch_app() -> void:
    if not server.is_listening():
        _start_server()
    if not server.is_listening():
        return
    var err := OS.shell_open(URL)
    if err == OK:
        status_label.text = "DFG Builder opened in the browser."
    else:
        status_label.text = "Could not open the browser. Error: " + str(err)

func _open_project(path: String) -> void:
    if not server.is_listening():
        _start_server()
    var err := OS.shell_open(URL + "projects/" + path.get_file().uri_encode())
    status_label.text = ("Opened " + path.get_file()) if err == OK else "Could not open project."
